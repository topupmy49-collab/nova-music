# No special rules needed: minification is disabled in v1.0.
