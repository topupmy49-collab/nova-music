package com.novamusic.player.util

import com.novamusic.player.data.Song
import org.junit.Assert.assertEquals
import org.junit.Test

class FormatTest {

    private fun song(id: Long, title: String, artist: String) =
        Song(id, title, artist, "", 0L, 1000L, 0L)

    @Test fun duration_zero_and_negative() {
        assertEquals("0:00", Format.duration(0))
        assertEquals("0:00", Format.duration(-5))
        assertEquals("0:00", Format.duration(Long.MIN_VALUE + 1)) // C.TIME_UNSET
    }

    @Test fun duration_minutes_seconds() {
        assertEquals("0:09", Format.duration(9_000))
        assertEquals("1:05", Format.duration(65_000))
        assertEquals("59:59", Format.duration(3_599_000))
    }

    @Test fun duration_hours() {
        assertEquals("1:01:01", Format.duration(3_661_000))
    }

    @Test fun filter_blank_returns_all() {
        val list = listOf(song(1, "A", "X"), song(2, "B", "Y"))
        assertEquals(list, filterSongs(list, "   "))
    }

    @Test fun filter_matches_title_and_artist_case_insensitive() {
        val list = listOf(song(1, "Hello", "Adele"), song(2, "Yellow", "Coldplay"), song(3, "Zebra", "Nobody"))
        assertEquals(listOf(1L, 2L), filterSongs(list, "ELLO").map { it.id })
        assertEquals(listOf(1L), filterSongs(list, "adele").map { it.id })
    }

    @Test fun filter_no_match_is_empty() {
        val list = listOf(song(1, "Hello", "Adele"))
        assertEquals(emptyList<Song>(), filterSongs(list, "xyz"))
    }
}
