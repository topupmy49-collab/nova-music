package com.novamusic.player

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.InputFilter
import android.text.TextWatcher
import android.view.View
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ListView
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.isVisible
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionToken
import com.novamusic.player.playback.PlaybackService.Companion.CMD_SLEEP
import com.novamusic.player.playback.PlaybackService.Companion.KEY_MINUTES
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.common.util.concurrent.ListenableFuture
import com.novamusic.player.data.MediaRepository
import com.novamusic.player.data.Song
import com.novamusic.player.data.Store
import com.novamusic.player.databinding.ActivityMainBinding
import com.novamusic.player.playback.PlaybackService
import com.novamusic.player.ui.ArtworkLoader
import com.novamusic.player.ui.PlaylistAdapter
import com.novamusic.player.ui.SongAdapter
import com.novamusic.player.util.Format
import com.novamusic.player.util.filterSongs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private enum class Tab { HOME, SONGS, PLAYLISTS, FAVORITES, SETTINGS }

    private lateinit var b: ActivityMainBinding
    private lateinit var store: Store
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val handler = Handler(Looper.getMainLooper())

    private var controller: MediaController? = null
    private var controllerFuture: ListenableFuture<MediaController>? = null

    private var allSongs: List<Song> = emptyList()
    private var byId: Map<Long, Song> = emptyMap()
    private var songsLoaded = false
    private var loading = false
    private var loadError: String? = null
    private var restored = false

    private var tab = Tab.HOME
    private var openPlaylist: String? = null
    private var query = ""
    private var sortRecent = false
    private var permissionDenied = false
    private var permanentlyDenied = false
    private var dragging = false

    private var currentList: List<Song> = emptyList()
    private var homeList: List<Song> = emptyList()
    private var draggingVolume = false
    private lateinit var audio: AudioManager
    private lateinit var songAdapter: SongAdapter
    private lateinit var homeAdapter: SongAdapter
    private lateinit var playlistAdapter: PlaylistAdapter

    private val audioPermission: String
        get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private val requestAudio =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                permissionDenied = false
                loadLibrary()
            } else {
                permissionDenied = true
                permanentlyDenied = !shouldShowRequestPermissionRationale(audioPermission)
                render()
            }
        }

    private val requestNotifications =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (!granted) toast(R.string.toast_notif_denied)
        }

    private val backCallback = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() {
            if (openPlaylist != null) {
                openPlaylist = null
                query = ""
                b.searchInput.setText("")
                render()
            }
            updateBack()
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            updateProgress()
            handler.postDelayed(this, 500)
        }
    }

    private val playerListener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            updateAll()
        }
    }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        store = Store(this)
        audio = getSystemService(AUDIO_SERVICE) as AudioManager

        ViewCompat.setOnApplyWindowInsetsListener(b.root) { v, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        onBackPressedDispatcher.addCallback(this, backCallback)

        songAdapter = SongAdapter(this, { index -> playFrom(currentList, index) }, { v, s -> showSongMenu(v, s) })
        playlistAdapter = PlaylistAdapter(this,
            { name -> openPlaylist = name; query = ""; b.searchInput.setText(""); render() },
            { v, name -> showPlaylistMenu(v, name) })
        homeAdapter = SongAdapter(this, { index -> playFrom(homeList, index) }, { v, s -> showSongMenu(v, s) })
        b.recycler.layoutManager = LinearLayoutManager(this)
        b.homeRecycler.layoutManager = LinearLayoutManager(this)
        b.homeRecycler.adapter = homeAdapter
        b.miniArt.clipToOutline = true
        b.npArt.clipToOutline = true

        b.bottomNav.setOnItemSelectedListener { item ->
            tab = when (item.itemId) {
                R.id.nav_songs -> Tab.SONGS
                R.id.nav_playlists -> Tab.PLAYLISTS
                R.id.nav_favorites -> Tab.FAVORITES
                R.id.nav_settings -> Tab.SETTINGS
                else -> Tab.HOME
            }
            openPlaylist = null
            query = ""
            b.searchInput.setText("")
            render()
            true
        }

        b.searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b4: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = s?.toString() ?: ""
                if (q != query) {
                    query = q
                    render()
                }
            }
        })

        b.btnRefresh.setOnClickListener { loadLibrary() }
        b.btnRescan.setOnClickListener { loadLibrary() }
        b.btnClearHistory.setOnClickListener {
            confirm(R.string.confirm_clear_history, null, R.string.clear) { store.clearRecents(); render() }
        }
        b.btnClearFavorites.setOnClickListener {
            confirm(R.string.confirm_clear_favorites, null, R.string.clear) { store.clearFavorites(); render(); updateAll() }
        }

        // Mini player + Now Playing controls
        b.miniPlayer.setOnClickListener { goHome() }
        b.btnScan.setOnClickListener { loadLibrary() }
        b.miniPlay.setOnClickListener { togglePlay() }
        b.npQueue.setOnClickListener { showQueue() }
        b.npPlay.setOnClickListener { togglePlay() }
        b.npNext.setOnClickListener { controller?.seekToNext() }
        b.npPrev.setOnClickListener { controller?.seekToPrevious() }
        b.npShuffle.setOnClickListener { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } }
        b.npRepeat.setOnClickListener {
            controller?.let {
                it.repeatMode = when (it.repeatMode) {
                    Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                    Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                    else -> Player.REPEAT_MODE_OFF
                }
            }
        }
        b.npFav.setOnClickListener {
            val id = controller?.currentMediaItem?.mediaId?.toLongOrNull() ?: return@setOnClickListener
            store.toggleFavorite(id)
            updateNowPlaying()
            if (tab == Tab.FAVORITES) render()
        }
        b.npSpeed.setOnClickListener { showSpeedMenu(it) }
        b.npSleep.setOnClickListener { showSleepMenu(it) }
        b.volSeek.max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        b.volSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) audio.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0)
            }

            override fun onStartTrackingTouch(sb: SeekBar) {
                draggingVolume = true
            }

            override fun onStopTrackingTouch(sb: SeekBar) {
                draggingVolume = false
            }
        })
        b.npSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) b.npElapsed.text = Format.duration(progress.toLong())
            }

            override fun onStartTrackingTouch(sb: SeekBar) {
                dragging = true
            }

            override fun onStopTrackingTouch(sb: SeekBar) {
                dragging = false
                controller?.seekTo(sb.progress.toLong())
            }
        })

        if (!hasAudioPermission()) requestAudio.launch(audioPermission)
        render()
    }

    override fun onStart() {
        super.onStart()
        connectController()
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    override fun onResume() {
        super.onResume()
        if (hasAudioPermission()) {
            permissionDenied = false
            if (!songsLoaded && !loading) loadLibrary()
        } else {
            render()
        }
    }

    override fun onStop() {
        handler.removeCallbacks(ticker)
        controller?.removeListener(playerListener)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
        controllerFuture = null
        super.onStop()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ controller

    private fun connectController() {
        if (controllerFuture != null) return
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        controllerFuture = future
        future.addListener({
            try {
                val c = future.get()
                if (controllerFuture !== future) return@addListener
                controller = c
                c.addListener(playerListener)
                if (c.mediaItemCount == 0) {
                    c.shuffleModeEnabled = store.shuffle
                    c.repeatMode = store.repeatMode
                }
                maybeRestore()
                updateAll()
            } catch (e: Exception) {
                if (controllerFuture === future) controllerFuture = null
            }
        }, ContextCompat.getMainExecutor(this))
    }

    /** Re-loads the last queue (paused) after the app is reopened and the service has nothing queued. */
    private fun maybeRestore() {
        val c = controller ?: return
        if (restored || !songsLoaded) return
        restored = true
        if (c.mediaItemCount > 0) return
        val saved = store.loadQueue() ?: return
        val songs = saved.ids.mapNotNull { byId[it] }
        if (songs.isEmpty() || songs.size != saved.ids.size) return
        val index = saved.index.coerceIn(0, songs.size - 1)
        c.setMediaItems(songs.map { toItem(it) }, index, saved.positionMs)
        c.prepare()
    }

    private fun toItem(song: Song): MediaItem =
        MediaItem.Builder()
            .setMediaId(song.id.toString())
            .setUri(song.uri)
            .setRequestMetadata(MediaItem.RequestMetadata.Builder().setMediaUri(song.uri).build())
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(song.title)
                    .setArtist(song.artist)
                    .setAlbumTitle(song.album)
                    .setArtworkUri(song.albumArtUri)
                    .setIsPlayable(true)
                    .build()
            )
            .build()

    private fun playFrom(list: List<Song>, index: Int) {
        val c = controller
        if (c == null) {
            toast(R.string.toast_player_connecting)
            return
        }
        if (list.isEmpty()) return
        ensureNotificationPermission()
        var start = 0
        var end = list.size
        if (list.size > MAX_QUEUE) {
            start = (index - MAX_QUEUE / 2).coerceAtLeast(0)
            end = minOf(list.size, start + MAX_QUEUE)
            start = maxOf(0, end - MAX_QUEUE)
        }
        c.setMediaItems(list.subList(start, end).map { toItem(it) }, index - start, 0L)
        c.prepare()
        c.play()
    }

    private fun shuffleAll(list: List<Song>) {
        if (list.isEmpty()) return
        playFrom(list.shuffled().take(MAX_QUEUE), 0)
    }

    private fun togglePlay() {
        val c = controller ?: return
        if (c.mediaItemCount == 0) {
            val start = store.recents().mapNotNull { byId[it] }.ifEmpty { allSongs }
            playFrom(start, 0)
            return
        }
        if (c.isPlaying) {
            c.pause()
        } else {
            if (c.playbackState == Player.STATE_IDLE) c.prepare()
            c.play()
        }
    }

    private fun ensureNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // ------------------------------------------------------------------ library

    private fun hasAudioPermission() =
        ContextCompat.checkSelfPermission(this, audioPermission) == PackageManager.PERMISSION_GRANTED

    private fun loadLibrary() {
        if (!hasAudioPermission()) {
            render()
            return
        }
        if (loading) return
        loading = true
        loadError = null
        render()
        scope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching { MediaRepository.loadSongs(applicationContext) }
            }
            loading = false
            val songs = result.getOrNull()
            if (songs != null) {
                allSongs = songs
                byId = songs.associateBy { it.id }
                songsLoaded = true
            } else {
                loadError = result.exceptionOrNull()?.message ?: "Unknown error"
            }
            render()
            maybeRestore()
            updateAll()
        }
    }

    // ------------------------------------------------------------------ rendering

    private fun showState(text: String, buttonText: String? = null, action: (() -> Unit)? = null) {
        b.stateBox.isVisible = true
        b.stateText.text = text
        b.stateButton.isVisible = buttonText != null
        if (buttonText != null) {
            b.stateButton.text = buttonText
            b.stateButton.setOnClickListener { action?.invoke() }
        }
    }

    private fun setTools(aText: String?, aAct: (() -> Unit)?, bText: String? = null, bAct: (() -> Unit)? = null) {
        b.toolbarRow.isVisible = aText != null
        b.btnToolA.isVisible = aText != null
        if (aText != null) {
            b.btnToolA.text = aText
            b.btnToolA.setOnClickListener { aAct?.invoke() }
        }
        b.btnToolB.isVisible = bText != null
        if (bText != null) {
            b.btnToolB.text = bText
            b.btnToolB.setOnClickListener { bAct?.invoke() }
        }
    }

    private fun showList(list: List<Song>, emptyText: Int) {
        currentList = list
        if (list.isEmpty()) {
            showState(getString(if (query.isNotBlank()) R.string.state_no_match else emptyText))
        } else {
            if (b.recycler.adapter !== songAdapter) b.recycler.adapter = songAdapter
            songAdapter.submit(list)
            b.recycler.isVisible = true
        }
    }

    private fun render() {
        updateBack()
        b.progress.isVisible = false
        b.stateBox.isVisible = false
        b.recycler.isVisible = false
        b.homePanel.isVisible = false
        b.settingsPanel.isVisible = false
        b.searchInput.isVisible = false
        b.sectionSubtitle.isVisible = false
        setTools(null, null)

        b.sectionTitle.isVisible = tab != Tab.HOME
        b.sectionTitle.text = getString(
            when (tab) {
                Tab.HOME -> R.string.section_recent
                Tab.SONGS -> R.string.section_songs
                Tab.PLAYLISTS -> R.string.section_playlists
                Tab.FAVORITES -> R.string.section_favorites
                Tab.SETTINGS -> R.string.section_settings
            }
        )

        if (tab == Tab.SETTINGS) {
            b.settingsPanel.isVisible = true
            b.setVersion.text = getString(R.string.settings_version, versionName())
            return
        }
        if (!hasAudioPermission()) {
            if (permissionDenied && permanentlyDenied) {
                showState(getString(R.string.state_permission), getString(R.string.btn_open_settings)) {
                    startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                    )
                }
            } else {
                showState(getString(R.string.state_permission), getString(R.string.btn_allow)) {
                    requestAudio.launch(audioPermission)
                }
            }
            return
        }
        if (loading) {
            b.progress.isVisible = true
            return
        }
        loadError?.let {
            showState(getString(R.string.error_library, it), getString(R.string.btn_retry)) { loadLibrary() }
            return
        }
        if (!songsLoaded) {
            b.progress.isVisible = true
            return
        }
        if (allSongs.isEmpty()) {
            showState(getString(R.string.state_empty_library), getString(R.string.btn_refresh)) { loadLibrary() }
            return
        }

        val total = allSongs.sumOf { it.durationMs }
        val summary = getString(R.string.summary_library, allSongs.size, Format.duration(total))

        when (tab) {
            Tab.HOME -> {
                homeList = store.recents().mapNotNull { byId[it] }
                b.homePanel.isVisible = true
                b.homeListTitle.text = getString(R.string.home_recent, homeList.size)
                b.homeEmpty.isVisible = homeList.isEmpty()
                homeAdapter.submit(homeList)
                updateNowPlaying()
            }
            Tab.SONGS -> {
                b.sectionSubtitle.isVisible = true
                b.sectionSubtitle.text = summary
                b.searchInput.isVisible = true
                setTools(
                    getString(if (sortRecent) R.string.sort_recent else R.string.sort_az),
                    { sortRecent = !sortRecent; render() },
                    getString(R.string.shuffle_all),
                    { shuffleAll(allSongs) }
                )
                val base = if (sortRecent) allSongs.sortedByDescending { it.dateAdded } else allSongs
                showList(filterSongs(base, query), R.string.state_empty_library)
            }
            Tab.FAVORITES -> {
                b.searchInput.isVisible = true
                val favs = store.favorites()
                val list = store.favorites().let { f -> allSongs.filter { it.id in f } }
                if (favs.isNotEmpty()) {
                    setTools(getString(R.string.shuffle), { shuffleAll(list) })
                }
                showList(filterSongs(list, query), R.string.state_no_favorites)
            }
            Tab.PLAYLISTS -> renderPlaylists()
            Tab.SETTINGS -> Unit
        }
    }

    private fun renderPlaylists() {
        val name = openPlaylist
        if (name == null) {
            val pls = store.playlists()
            setTools(getString(R.string.new_playlist), { promptNewPlaylist { render() } })
            if (pls.isEmpty()) {
                showState(getString(R.string.state_no_playlists))
            } else {
                if (b.recycler.adapter !== playlistAdapter) b.recycler.adapter = playlistAdapter
                playlistAdapter.submit(pls)
                b.recycler.isVisible = true
            }
            return
        }
        val pl = store.playlists().firstOrNull { it.name == name }
        if (pl == null) {
            openPlaylist = null
            render()
            return
        }
        val songs = pl.ids.mapNotNull { byId[it] }
        b.sectionTitle.text = name
        b.searchInput.isVisible = true
        setTools(
            getString(R.string.play), { playFrom(songs, 0) },
            getString(R.string.shuffle), { shuffleAll(songs) }
        )
        showList(filterSongs(songs, query), R.string.state_empty_playlist)
    }

    private fun updateBack() {
        backCallback.isEnabled = openPlaylist != null
    }

    private fun versionName(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: ""
    } catch (e: Exception) {
        ""
    }

    // ------------------------------------------------------------------ player UI

    private fun updateAll() {
        updateMini()
        updateNowPlaying()
        val cur = controller?.currentMediaItem?.mediaId?.toLongOrNull() ?: -1L
        songAdapter.setCurrent(cur)
        homeAdapter.setCurrent(cur)
    }

    private fun updateMini() {
        val c = controller
        val item = c?.currentMediaItem
        if (c == null || item == null) {
            b.miniPlayer.isVisible = false
            return
        }
        b.miniPlayer.isVisible = true
        b.miniTitle.text = item.mediaMetadata.title ?: getString(R.string.unknown_title)
        b.miniArtist.text = item.mediaMetadata.artist ?: getString(R.string.unknown_artist)
        b.miniPlay.setImageResource(if (c.isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        b.miniPlay.contentDescription = getString(if (c.isPlaying) R.string.desc_pause else R.string.desc_play)
        val song = item.mediaId.toLongOrNull()?.let { byId[it] }
        if (song != null) ArtworkLoader.load(this, song, b.miniArt, 128)
        else b.miniArt.setImageResource(R.drawable.ic_music_note)
    }

    private fun updateNowPlaying() {
        val c = controller
        val item = c?.currentMediaItem
        if (c == null || item == null) {
            b.npTitle.text = getString(R.string.welcome_title)
            b.npArtist.text = getString(R.string.welcome_sub)
            b.npArt.setImageResource(R.drawable.art_vinyl)
            b.npPlay.setImageResource(R.drawable.ic_play)
            return
        }
        b.npTitle.text = item.mediaMetadata.title ?: getString(R.string.unknown_title)
        b.npArtist.text = item.mediaMetadata.artist ?: getString(R.string.unknown_artist)
        val id = item.mediaId.toLongOrNull()
        val song = id?.let { byId[it] }
        if (song != null) ArtworkLoader.load(this, song, b.npArt, 600, R.drawable.art_vinyl)
        else b.npArt.setImageResource(R.drawable.art_vinyl)
        b.npFav.setImageResource(
            if (id != null && store.favorites().contains(id)) R.drawable.ic_favorite else R.drawable.ic_favorite_border
        )
        b.npPlay.setImageResource(if (c.isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        b.npPlay.contentDescription = getString(if (c.isPlaying) R.string.desc_pause else R.string.desc_play)
        val on = ContextCompat.getColor(this, R.color.neon)
        val off = ContextCompat.getColor(this, R.color.text_secondary)
        b.npShuffle.setColorFilter(if (c.shuffleModeEnabled) on else off)
        b.npRepeat.setImageResource(
            if (c.repeatMode == Player.REPEAT_MODE_ONE) R.drawable.ic_repeat_one else R.drawable.ic_repeat
        )
        b.npRepeat.setColorFilter(if (c.repeatMode == Player.REPEAT_MODE_OFF) off else on)
        b.npSpeed.text = getString(R.string.speed_label, String.format(java.util.Locale.US, "%.2f", c.playbackParameters.speed).trimEnd('0').trimEnd('.').let { if (it.contains('.')) it else "$it.0" })
        updateProgress()
    }

    private fun updateProgress() {
        if (!draggingVolume) b.volSeek.progress = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
        val end = store.sleepEndAt
        val left = ((end - System.currentTimeMillis()) / 60_000L).toInt() + 1
        b.npSleep.text = if (end > 0L && left > 0) getString(R.string.sleep_left, left) else getString(R.string.sleep_off)
        val c = controller ?: return
        if (dragging) return
        val dur = c.duration
        val pos = c.currentPosition.coerceAtLeast(0L)
        if (dur != C.TIME_UNSET && dur > 0) {
            b.npSeek.max = dur.toInt()
            b.npSeek.progress = pos.coerceAtMost(dur).toInt()
            b.npRemaining.text = "-" + Format.duration(dur - pos)
        } else {
            b.npSeek.max = 0
            b.npSeek.progress = 0
            b.npRemaining.text = "-0:00"
        }
        b.npElapsed.text = Format.duration(pos)
    }

    private fun goHome() {
        b.bottomNav.selectedItemId = R.id.nav_home
        b.homePanel.post { b.homePanel.scrollTo(0, 0) }
    }

    private fun showSpeedMenu(anchor: View) {
        val c = controller ?: return
        val speeds = floatArrayOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
        val popup = PopupMenu(this, anchor)
        speeds.forEachIndexed { i, sp -> popup.menu.add(0, i, i, "$sp×") }
        popup.setOnMenuItemClickListener { item ->
            c.setPlaybackSpeed(speeds[item.itemId])
            true
        }
        popup.show()
    }

    private fun showSleepMenu(anchor: View) {
        val minutes = intArrayOf(15, 30, 45, 60)
        val popup = PopupMenu(this, anchor)
        popup.menu.add(0, 0, 0, R.string.sleep_menu_off)
        minutes.forEachIndexed { i, m -> popup.menu.add(0, m, i + 1, getString(R.string.sleep_menu_min, m)) }
        popup.setOnMenuItemClickListener { item ->
            setSleep(item.itemId)
            true
        }
        popup.show()
    }

    private fun setSleep(minutes: Int) {
        val c = controller
        if (c == null) {
            toast(R.string.toast_sleep_failed)
            return
        }
        val args = Bundle().apply { putInt(KEY_MINUTES, minutes) }
        c.sendCustomCommand(SessionCommand(CMD_SLEEP, Bundle.EMPTY), args)
        // Show the new state right away; the service stores the real end time a moment later.
        handler.postDelayed({ updateProgress() }, 300)
        if (minutes > 0) {
            Toast.makeText(this, getString(R.string.toast_sleep_set, minutes), Toast.LENGTH_SHORT).show()
        } else {
            toast(R.string.toast_sleep_off)
        }
    }

    private fun showQueue() {
        val c = controller ?: return
        if (c.mediaItemCount == 0) {
            toast(R.string.toast_queue_empty)
            return
        }
        val current = c.currentMediaItemIndex
        val titles = ArrayList<String>()
        for (i in 0 until c.mediaItemCount) {
            val t = c.getMediaItemAt(i).mediaMetadata.title?.toString() ?: getString(R.string.unknown_title)
            titles.add(if (i == current) "▶ $t" else t)
        }
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, titles)
        val list = ListView(this)
        list.adapter = adapter
        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle(R.string.queue_title)
            .setView(list)
            .setPositiveButton(R.string.close, null)
            .create()
        list.setOnItemClickListener { _, _, pos, _ ->
            c.seekToDefaultPosition(pos)
            c.play()
            dialog.dismiss()
        }
        list.setOnItemLongClickListener { _, _, pos, _ ->
            c.removeMediaItem(pos)
            titles.removeAt(pos)
            adapter.notifyDataSetChanged()
            true
        }
        dialog.show()
    }

    // ------------------------------------------------------------------ menus & dialogs

    private fun showSongMenu(anchor: View, song: Song) {
        val isFav = store.favorites().contains(song.id)
        val popup = PopupMenu(this, anchor)
        popup.menu.add(0, 1, 0, R.string.play_next)
        popup.menu.add(0, 2, 1, R.string.add_to_queue)
        popup.menu.add(0, 3, 2, if (isFav) R.string.remove_favorite else R.string.add_favorite)
        popup.menu.add(0, 4, 3, R.string.add_to_playlist)
        val inPlaylist = if (tab == Tab.PLAYLISTS) openPlaylist else null
        if (inPlaylist != null) popup.menu.add(0, 5, 4, R.string.remove_from_playlist)
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> enqueue(song, next = true)
                2 -> enqueue(song, next = false)
                3 -> {
                    store.toggleFavorite(song.id)
                    updateNowPlaying()
                    render()
                }
                4 -> choosePlaylistFor(song)
                5 -> {
                    store.removeFromPlaylist(inPlaylist!!, song.id)
                    render()
                }
            }
            true
        }
        popup.show()
    }

    private fun enqueue(song: Song, next: Boolean) {
        val c = controller
        if (c == null) {
            toast(R.string.toast_player_connecting)
            return
        }
        if (c.mediaItemCount == 0) {
            playFrom(listOf(song), 0)
            return
        }
        if (next) c.addMediaItem(c.currentMediaItemIndex + 1, toItem(song)) else c.addMediaItem(toItem(song))
        toast(R.string.toast_added_queue)
    }

    private fun choosePlaylistFor(song: Song) {
        val pls = store.playlists()
        val names = pls.map { it.name } + getString(R.string.new_playlist_ellipsis)
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.add_to_playlist)
            .setItems(names.toTypedArray()) { _, which ->
                if (which == pls.size) {
                    promptNewPlaylist { name -> addToPlaylist(name, song) }
                } else {
                    addToPlaylist(pls[which].name, song)
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun addToPlaylist(name: String, song: Song) {
        val added = store.addToPlaylist(name, song.id)
        Toast.makeText(
            this,
            getString(if (added) R.string.toast_added_playlist else R.string.toast_already_in_playlist, name),
            Toast.LENGTH_SHORT
        ).show()
        render()
    }

    private fun showPlaylistMenu(anchor: View, name: String) {
        val popup = PopupMenu(this, anchor)
        popup.menu.add(0, 1, 0, R.string.delete_playlist)
        popup.setOnMenuItemClickListener {
            confirm(R.string.confirm_delete_playlist_title,
                getString(R.string.confirm_delete_playlist_msg, name), R.string.delete) {
                store.deletePlaylist(name)
                render()
            }
            true
        }
        popup.show()
    }

    private fun promptNewPlaylist(onCreated: (String) -> Unit) {
        val input = EditText(this).apply {
            hint = getString(R.string.playlist_name_hint)
            setSingleLine()
            filters = arrayOf(InputFilter.LengthFilter(40))
        }
        val box = FrameLayout(this).apply {
            setPadding(dp(24), dp(8), dp(24), 0)
            addView(input)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.new_playlist)
            .setView(box)
            .setPositiveButton(R.string.create) { _, _ ->
                val name = input.text.toString().trim()
                if (store.createPlaylist(name)) onCreated(name) else toast(R.string.toast_playlist_exists)
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun confirm(title: Int, message: String?, positive: Int, onYes: () -> Unit) {
        val builder = MaterialAlertDialogBuilder(this).setTitle(title)
        if (message != null) builder.setMessage(message)
        builder.setPositiveButton(positive) { _, _ -> onYes() }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun toast(res: Int) = Toast.makeText(this, res, Toast.LENGTH_SHORT).show()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private companion object {
        const val MAX_QUEUE = 300
    }
}
