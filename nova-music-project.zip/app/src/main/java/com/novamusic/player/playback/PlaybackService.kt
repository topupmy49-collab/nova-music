package com.novamusic.player.playback

import android.app.PendingIntent
import android.content.Intent
import android.widget.Toast
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import com.novamusic.player.MainActivity
import com.novamusic.player.R
import com.novamusic.player.data.Store

/**
 * Owns the ExoPlayer and the MediaSession. Media3 shows the media notification and lock-screen
 * controls automatically and runs this service in the foreground only while audio is playing.
 */
class PlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null
    private lateinit var store: Store
    private var consecutiveErrors = 0

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            if (isPlaying) {
                consecutiveErrors = 0
                mediaSession?.player?.currentMediaItem?.mediaId?.toLongOrNull()?.let { store.addRecent(it) }
            } else {
                saveQueue()
            }
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            val p = mediaSession?.player
            if (mediaItem != null && p != null && p.playWhenReady &&
                reason != Player.MEDIA_ITEM_TRANSITION_REASON_PLAYLIST_CHANGED
            ) {
                mediaItem.mediaId.toLongOrNull()?.let { store.addRecent(it) }
            }
            saveQueue()
        }

        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
            store.shuffle = shuffleModeEnabled
        }

        override fun onRepeatModeChanged(repeatMode: Int) {
            store.repeatMode = repeatMode
        }

        override fun onPlayerError(error: PlaybackException) {
            val p = mediaSession?.player ?: return
            Toast.makeText(applicationContext, R.string.error_unplayable, Toast.LENGTH_SHORT).show()
            consecutiveErrors++
            // Skip unreadable files, but stop if every song in a row fails.
            if (p.hasNextMediaItem() && consecutiveErrors <= p.mediaItemCount) {
                p.seekToNextMediaItem()
                p.prepare()
                p.play()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        store = Store(this)

        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                /* handleAudioFocus = */ true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        player.addListener(listener)

        val openApp = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        mediaSession = MediaSession.Builder(this, player)
            .setCallback(Callback())
            .setSessionActivity(openApp)
            .build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    /** Swiping the app away stops the service unless music is actively playing. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = mediaSession?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        saveQueue()
        mediaSession?.run {
            player.removeListener(listener)
            player.release()
            release()
        }
        mediaSession = null
        super.onDestroy()
    }

    private fun saveQueue() {
        val p = mediaSession?.player ?: return
        if (p.mediaItemCount == 0) {
            store.clearQueue()
            return
        }
        val ids = ArrayList<Long>(p.mediaItemCount)
        for (i in 0 until p.mediaItemCount) {
            p.getMediaItemAt(i).mediaId.toLongOrNull()?.let { ids.add(it) }
        }
        store.saveQueue(ids, p.currentMediaItemIndex, p.currentPosition.coerceAtLeast(0L))
    }

    /** Makes sure items sent by the app controller always carry a playable URI. */
    private inner class Callback : MediaSession.Callback {
        override fun onAddMediaItems(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
            mediaItems: MutableList<MediaItem>
        ): ListenableFuture<MutableList<MediaItem>> {
            val resolved = mediaItems.map { item ->
                val uri = item.localConfiguration?.uri ?: item.requestMetadata.mediaUri
                if (uri != null) item.buildUpon().setUri(uri).build() else item
            }.toMutableList()
            return Futures.immediateFuture(resolved)
        }
    }
}
