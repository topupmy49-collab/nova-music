package com.novamusic.player.data

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

/** Small local persistence layer (SharedPreferences + JSON). Everything stays on the device. */
class Store(context: Context) {

    data class Playlist(val name: String, val ids: List<Long>)
    data class SavedQueue(val ids: List<Long>, val index: Int, val positionMs: Long)

    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("nova_store", Context.MODE_PRIVATE)

    private fun readIds(key: String): MutableList<Long> {
        val raw = sp.getString(key, null) ?: return mutableListOf()
        return try {
            val a = JSONArray(raw)
            MutableList(a.length()) { a.getLong(it) }
        } catch (e: JSONException) {
            mutableListOf()
        }
    }

    private fun writeIds(key: String, ids: List<Long>) {
        sp.edit().putString(key, JSONArray(ids).toString()).apply()
    }

    // ---------- favorites ----------
    fun favorites(): Set<Long> = readIds(KEY_FAVORITES).toSet()

    /** Returns true if the song is now a favorite. */
    fun toggleFavorite(id: Long): Boolean {
        val list = readIds(KEY_FAVORITES)
        val nowFavorite = if (list.contains(id)) {
            list.remove(id)
            false
        } else {
            list.add(0, id)
            true
        }
        writeIds(KEY_FAVORITES, list)
        return nowFavorite
    }

    fun clearFavorites() = sp.edit().remove(KEY_FAVORITES).apply()

    // ---------- recently played ----------
    fun recents(): List<Long> = readIds(KEY_RECENTS)

    fun addRecent(id: Long) {
        val list = readIds(KEY_RECENTS)
        list.remove(id)
        list.add(0, id)
        writeIds(KEY_RECENTS, list.take(MAX_RECENTS))
    }

    fun clearRecents() = sp.edit().remove(KEY_RECENTS).apply()

    // ---------- playlists ----------
    fun playlists(): List<Playlist> {
        val raw = sp.getString(KEY_PLAYLISTS, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val ids = o.getJSONArray("ids")
                Playlist(o.getString("name"), List(ids.length()) { ids.getLong(it) })
            }
        } catch (e: JSONException) {
            emptyList()
        }
    }

    private fun savePlaylists(list: List<Playlist>) {
        val arr = JSONArray()
        list.forEach { p ->
            arr.put(JSONObject().put("name", p.name).put("ids", JSONArray(p.ids)))
        }
        sp.edit().putString(KEY_PLAYLISTS, arr.toString()).apply()
    }

    /** Returns false if the name is blank or already used. */
    fun createPlaylist(name: String): Boolean {
        val n = name.trim()
        val all = playlists()
        if (n.isEmpty() || all.any { it.name.equals(n, ignoreCase = true) }) return false
        savePlaylists(all + Playlist(n, emptyList()))
        return true
    }

    fun deletePlaylist(name: String) = savePlaylists(playlists().filter { it.name != name })

    /** Returns false if the song was already in the playlist. */
    fun addToPlaylist(name: String, id: Long): Boolean {
        var added = false
        savePlaylists(playlists().map { p ->
            if (p.name == name && !p.ids.contains(id)) {
                added = true
                p.copy(ids = p.ids + id)
            } else p
        })
        return added
    }

    fun removeFromPlaylist(name: String, id: Long) {
        savePlaylists(playlists().map { p ->
            if (p.name == name) p.copy(ids = p.ids.filter { it != id }) else p
        })
    }

    // ---------- playback state ----------
    fun saveQueue(ids: List<Long>, index: Int, positionMs: Long) {
        sp.edit()
            .putString(KEY_QUEUE, JSONArray(ids).toString())
            .putInt(KEY_QUEUE_INDEX, index)
            .putLong(KEY_QUEUE_POS, positionMs)
            .apply()
    }

    fun clearQueue() = sp.edit().remove(KEY_QUEUE).apply()

    fun loadQueue(): SavedQueue? {
        val ids = readIds(KEY_QUEUE)
        if (ids.isEmpty()) return null
        return SavedQueue(ids, sp.getInt(KEY_QUEUE_INDEX, 0), sp.getLong(KEY_QUEUE_POS, 0L))
    }

    var shuffle: Boolean
        get() = sp.getBoolean(KEY_SHUFFLE, false)
        set(v) = sp.edit().putBoolean(KEY_SHUFFLE, v).apply()

    /** Same int values as androidx.media3.common.Player.REPEAT_MODE_*. */
    var repeatMode: Int
        get() = sp.getInt(KEY_REPEAT, 0)
        set(v) = sp.edit().putInt(KEY_REPEAT, v).apply()

    private companion object {
        const val KEY_FAVORITES = "favorites"
        const val KEY_RECENTS = "recents"
        const val KEY_PLAYLISTS = "playlists"
        const val KEY_QUEUE = "queue_ids"
        const val KEY_QUEUE_INDEX = "queue_index"
        const val KEY_QUEUE_POS = "queue_pos"
        const val KEY_SHUFFLE = "shuffle"
        const val KEY_REPEAT = "repeat"
        const val MAX_RECENTS = 50
    }
}
