package com.novamusic.player.ui

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.novamusic.player.R
import com.novamusic.player.data.Store
import com.novamusic.player.databinding.ItemSongBinding

class PlaylistAdapter(
    private val context: Context,
    private val onClick: (String) -> Unit,
    private val onMore: (View, String) -> Unit
) : RecyclerView.Adapter<PlaylistAdapter.VH>() {

    private var items: List<Store.Playlist> = emptyList()

    class VH(val b: ItemSongBinding) : RecyclerView.ViewHolder(b.root)

    fun submit(list: List<Store.Playlist>) {
        items = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemSongBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        b.art.clipToOutline = true
        return VH(b)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val p = items[position]
        val b = holder.b
        b.title.text = p.name
        b.title.setTextColor(context.getColor(R.color.text_primary))
        b.subtitle.text = context.resources.getQuantityString(R.plurals.songs_count, p.ids.size, p.ids.size)
        b.art.setImageResource(R.drawable.ic_queue_music)
        b.root.setOnClickListener { onClick(p.name) }
        b.more.setOnClickListener { onMore(it, p.name) }
    }
}
