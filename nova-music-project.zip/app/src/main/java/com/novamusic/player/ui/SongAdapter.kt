package com.novamusic.player.ui

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.novamusic.player.R
import com.novamusic.player.data.Song
import com.novamusic.player.databinding.ItemSongBinding
import com.novamusic.player.util.Format

class SongAdapter(
    private val context: Context,
    private val onClick: (Int) -> Unit,
    private val onMore: (View, Song) -> Unit
) : RecyclerView.Adapter<SongAdapter.VH>() {

    private var items: List<Song> = emptyList()
    private var currentId = -1L

    class VH(val b: ItemSongBinding) : RecyclerView.ViewHolder(b.root)

    fun submit(list: List<Song>) {
        items = list
        notifyDataSetChanged()
    }

    fun setCurrent(id: Long) {
        if (id != currentId) {
            currentId = id
            notifyDataSetChanged()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemSongBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        b.art.clipToOutline = true
        return VH(b)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val s = items[position]
        val b = holder.b
        b.title.text = s.title
        b.title.setTextColor(
            ContextCompat.getColor(context, if (s.id == currentId) R.color.neon else R.color.text_primary)
        )
        b.subtitle.text = "${s.artist} • ${Format.duration(s.durationMs)}"
        ArtworkLoader.load(context, s, b.art, 128)
        b.root.setOnClickListener {
            val p = holder.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onClick(p)
        }
        b.more.setOnClickListener { onMore(it, s) }
    }
}
