package com.novamusic.player.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.util.LruCache
import android.util.Size
import android.widget.ImageView
import com.novamusic.player.R
import com.novamusic.player.data.Song
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Collections

/** Loads album art in the background; falls back to a music-note placeholder when none exists. */
object ArtworkLoader {
    private val cache = LruCache<String, Bitmap>(80)
    private val misses: MutableSet<String> = Collections.synchronizedSet(HashSet())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun load(context: Context, song: Song, view: ImageView, size: Int) {
        val key = "${song.id}_$size"
        view.tag = key
        val hit = cache.get(key)
        if (hit != null) {
            view.setImageBitmap(hit)
            return
        }
        view.setImageResource(R.drawable.ic_music_note)
        if (misses.contains(key)) return
        val app = context.applicationContext
        scope.launch {
            val bmp = decode(app, song, size)
            if (bmp == null) {
                misses.add(key)
                return@launch
            }
            cache.put(key, bmp)
            withContext(Dispatchers.Main) {
                if (view.tag == key) view.setImageBitmap(bmp)
            }
        }
    }

    private fun decode(context: Context, song: Song, size: Int): Bitmap? = try {
        if (Build.VERSION.SDK_INT >= 29) {
            context.contentResolver.loadThumbnail(song.uri, Size(size, size), null)
        } else {
            context.contentResolver.openInputStream(song.albumArtUri)?.use { BitmapFactory.decodeStream(it) }
        }
    } catch (e: Exception) {
        null
    }
}
