package com.novamusic.player.data

import android.content.Context
import android.provider.MediaStore

/** Reads the device's local audio files through MediaStore. Nothing is uploaded anywhere. */
object MediaRepository {

    /** Must be called off the main thread. Throws SecurityException if permission is missing. */
    fun loadSongs(context: Context): List<Song> {
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATE_ADDED
        )
        val selection =
            "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} > 0"
        val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"

        val result = ArrayList<Song>()
        context.contentResolver.query(collection, projection, selection, null, sort)?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val albumIdCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val durCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val addedCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
            while (c.moveToNext()) {
                val rawTitle = c.getString(titleCol)
                val rawArtist = c.getString(artistCol)
                val rawAlbum = c.getString(albumCol)
                result.add(
                    Song(
                        id = c.getLong(idCol),
                        title = if (rawTitle.isNullOrBlank()) "Unknown title" else rawTitle,
                        artist = if (rawArtist.isNullOrBlank() || rawArtist == "<unknown>") "Unknown artist" else rawArtist,
                        album = if (rawAlbum.isNullOrBlank()) "" else rawAlbum,
                        albumId = c.getLong(albumIdCol),
                        durationMs = c.getLong(durCol),
                        dateAdded = c.getLong(addedCol)
                    )
                )
            }
        }
        return result
    }
}
