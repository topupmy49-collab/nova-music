package com.novamusic.player.util

import com.novamusic.player.data.Song
import java.util.Locale

object Format {
    /** 65_000 -> "1:05", 3_661_000 -> "1:01:01". Unknown/negative values -> "0:00". */
    fun duration(ms: Long): String {
        if (ms <= 0L) return "0:00"
        val total = ms / 1000
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%d:%02d", m, s)
    }
}

/** Case-insensitive search on title and artist. Blank query returns the full list. */
fun filterSongs(songs: List<Song>, query: String): List<Song> {
    val q = query.trim().lowercase()
    if (q.isEmpty()) return songs
    return songs.filter { it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) }
}
